package com.example.store_delivery_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
