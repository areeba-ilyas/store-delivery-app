// lib/models/product.dart
class Product {
  final String id;
  final String name;
  final String description;
  final double price;
  final double rating;
  final int reviewCount;
  final List<String> images;
  final List<String> categories;
  final bool isAvailable;
  final int stock;
  final bool isFeatured;
  final double? discountPrice;
  final String? brand;
  final String? size;
  final String? color;

  Product({
    required this.id,
    required this.name,
    required this.description,
    required this.price,
    required this.rating,
    required this.reviewCount,
    required this.images,
    required this.categories,
    required this.isAvailable,
    required this.stock,
    this.isFeatured = false,
    this.discountPrice,
    this.brand,
    this.size,
    this.color,
  });

  double get finalPrice => discountPrice ?? price;
  double get discountPercentage => discountPrice != null ? ((price - discountPrice!) / price * 100) : 0;
  bool get hasDiscount => discountPrice != null;
}