// lib/models/cart_item.dart
import 'package:store_delivery_app/models/product.dart';

class CartItem {
  final String id;
  final Product product;
  int quantity;
  final String? size;
  final String? color;

  CartItem({
    required this.id,
    required this.product,
    this.quantity = 1,
    this.size,
    this.color,
  });

  double get totalPrice => product.finalPrice * quantity;
}