// lib/models/notification.dart
import 'package:flutter/material.dart';

enum NotificationType {
  order('Order', Icons.shopping_bag),
  promotion('Promotion', Icons.local_offer),
  system('System', Icons.notifications),
  reminder('Reminder', Icons.alarm);

  final String value;
  final IconData icon;

  const NotificationType(this.value, this.icon);
}

class AppNotification {
  final String id;
  final String title;
  final String message;
  final NotificationType type;
  final DateTime date;
  final bool isRead;
  final Map<String, dynamic>? data;

  AppNotification({
    required this.id,
    required this.title,
    required this.message,
    required this.type,
    required this.date,
    this.isRead = false,
    this.data,
  });

  AppNotification copyWith({
    String? id,
    String? title,
    String? message,
    NotificationType? type,
    DateTime? date,
    bool? isRead,
    Map<String, dynamic>? data,
  }) {
    return AppNotification(
      id: id ?? this.id,
      title: title ?? this.title,
      message: message ?? this.message,
      type: type ?? this.type,
      date: date ?? this.date,
      isRead: isRead ?? this.isRead,
      data: data ?? this.data,
    );
  }
}