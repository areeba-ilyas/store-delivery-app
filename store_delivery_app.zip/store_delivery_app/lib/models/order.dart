// lib/models/order.dart
import 'dart:ui';

import '../theme/app_colors.dart';
import 'cart_item.dart';

enum OrderStatus {
  pending('Pending', 'Pending', AppColors.pending),
  processing('Processing', 'Processing', AppColors.processing),
  delivered('Delivered', 'Delivered', AppColors.delivered),
  cancelled('Cancelled', 'Cancelled', AppColors.cancelled);

  final String value;
  final String displayName;
  final Color color;

  const OrderStatus(this.value, this.displayName, this.color);
}

class Order {
  final String id;
  final List<CartItem> items;
  final double subtotal;
  final double tax;
  final double shipping;
  final double total;
  final OrderStatus status;
  final DateTime orderDate;
  final DateTime? deliveryDate;
  final String address;
  final String paymentMethod;

  Order({
    required this.id,
    required this.items,
    required this.subtotal,
    required this.tax,
    required this.shipping,
    required this.total,
    required this.status,
    required this.orderDate,
    this.deliveryDate,
    required this.address,
    required this.paymentMethod,
  });
}