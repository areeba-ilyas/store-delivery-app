// lib/screens/notifications/notifications_screen.dart
import 'package:flutter/material.dart';
import 'package:store_delivery_app/widgets/notification_card.dart';
import '../../theme/app_colors.dart';
import '../../models/notification.dart' as notif;

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  List<notif.AppNotification> notifications = [
    notif.AppNotification(
      id: '1',
      title: 'Order Confirmed',
      message: 'Your order #ORD001 has been confirmed and is being processed.',
      type: notif.NotificationType.order,
      date: DateTime.now().subtract(const Duration(minutes: 10)),
    ),
    notif.AppNotification(
      id: '2',
      title: 'Special Offer',
      message: 'Get 20% off on all electronics. Limited time offer!',
      type: notif.NotificationType.promotion,
      date: DateTime.now().subtract(const Duration(hours: 2)),
    ),
    notif.AppNotification(
      id: '3',
      title: 'Delivery Update',
      message: 'Your order will be delivered today between 2-4 PM.',
      type: notif.NotificationType.system,
      date: DateTime.now().subtract(const Duration(hours: 5)),
    ),
    notif.AppNotification(
      id: '4',
      title: 'Payment Successful',
      message: 'Payment for order #ORD002 has been processed successfully.',
      type: notif.NotificationType.order,
      date: DateTime.now().subtract(const Duration(days: 1)),
    ),
    notif.AppNotification(
      id: '5',
      title: 'New Arrivals',
      message: 'Check out our new collection of summer wear.',
      type: notif.NotificationType.promotion,
      date: DateTime.now().subtract(const Duration(days: 2)),
    ),
    notif.AppNotification(
      id: '6',
      title: 'Order Delivered',
      message: 'Your order #ORD003 has been delivered. Rate your experience.',
      type: notif.NotificationType.order,
      date: DateTime.now().subtract(const Duration(days: 3)),
      isRead: true,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
        actions: [
          TextButton(
            onPressed: _markAllAsRead,
            child: const Text(
              'Mark all as read',
              style: TextStyle(color: AppColors.primary),
            ),
          ),
        ],
      ),
      body: notifications.isEmpty
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.notifications_none_outlined,
              size: 100,
              color: AppColors.textLight,
            ),
            const SizedBox(height: 20),
            const Text(
              'No notifications',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              'You\'re all caught up!',
              style: TextStyle(color: AppColors.textSecondary),
            ),
          ],
        ),
      )
          : ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: notifications.length,
        itemBuilder: (context, index) {
          final notification = notifications[index];
          return NotificationCard(
            notification: notification,
            onTap: () {
              _markAsRead(notification.id);
            },
          );
        },
      ),
    );
  }

  void _markAsRead(String id) {
    setState(() {
      final index = notifications.indexWhere((n) => n.id == id);
      if (index != -1) {
        notifications[index] = notifications[index].copyWith(isRead: true);
      }
    });
  }

  void _markAllAsRead() {
    setState(() {
      notifications = notifications.map((n) {
        return n.copyWith(isRead: true);
      }).toList();
    });
  }
}