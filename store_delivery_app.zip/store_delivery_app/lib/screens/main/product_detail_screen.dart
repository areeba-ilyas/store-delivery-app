// lib/screens/main/product_detail_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:store_delivery_app/models/product.dart';
import 'package:store_delivery_app/providers/cart_provider.dart';
import 'package:store_delivery_app/widgets/custom_button.dart';
import '../../theme/app_colors.dart';

class ProductDetailScreen extends StatefulWidget {
  final Product product;

  const ProductDetailScreen({
    super.key,
    required this.product,
  });

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  int _selectedImageIndex = 0;
  int _quantity = 1;
  String? _selectedSize;
  String? _selectedColor;
  final PageController _imageController = PageController();

  @override
  void initState() {
    super.initState();
    // Auto animate images
    _startImageCarousel();
  }

  void _startImageCarousel() {
    Future.delayed(const Duration(seconds: 3), () {
      if (_selectedImageIndex < widget.product.images.length - 1) {
        _selectedImageIndex++;
      } else {
        _selectedImageIndex = 0;
      }
      if (_imageController.hasClients) {
        _imageController.animateToPage(
          _selectedImageIndex,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeInOut,
        );
      }
      _startImageCarousel();
    });
  }

  @override
  void dispose() {
    _imageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cartProvider = Provider.of<CartProvider>(context);

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 300.0,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                children: [
                  PageView.builder(
                    controller: _imageController,
                    itemCount: widget.product.images.length,
                    onPageChanged: (index) {
                      setState(() => _selectedImageIndex = index);
                    },
                    itemBuilder: (context, index) {
                      return Container(
                        width: double.infinity,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: NetworkImage(widget.product.images[index]),
                            fit: BoxFit.cover,
                          ),
                        ),
                      );
                    },
                  ),
                  Positioned(
                    bottom: 16.0,
                    left: 0.0,
                    right: 0.0,
                    child: Center(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(widget.product.images.length, (index) {
                          return Container(
                            width: 8.0,
                            height: 8.0,
                            margin: const EdgeInsets.symmetric(horizontal: 4.0),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: _selectedImageIndex == index
                                  ? Colors.white
                                  : Colors.white.withOpacity(0.5),
                            ),
                          );
                        }),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          widget.product.name,
                          style: const TextStyle(
                            fontSize: 24.0,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.favorite_border),
                        onPressed: () {},
                      ),
                    ],
                  ),
                  const SizedBox(height: 8.0),
                  Row(
                    children: [
                      // SIMPLE RATING WITHOUT PACKAGE
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: List.generate(5, (index) {
                          if (index < widget.product.rating.floor()) {
                            return const Icon(
                              Icons.star,
                              color: AppColors.rating,
                              size: 20.0,
                            );
                          } else if (index < widget.product.rating.ceil()) {
                            return const Icon(
                              Icons.star_half,
                              color: AppColors.rating,
                              size: 20.0,
                            );
                          } else {
                            return const Icon(
                              Icons.star_border,
                              color: AppColors.rating,
                              size: 20.0,
                            );
                          }
                        }),
                      ),
                      const SizedBox(width: 8.0),
                      Text(
                        '${widget.product.rating} (${widget.product.reviewCount} reviews)',
                        style: TextStyle(
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16.0),
                  Row(
                    children: [
                      Text(
                        '\$${widget.product.finalPrice.toStringAsFixed(2)}',
                        style: const TextStyle(
                          fontSize: 28.0,
                          fontWeight: FontWeight.w700,
                          color: AppColors.primary,
                        ),
                      ),
                      if (widget.product.hasDiscount) ...[
                        const SizedBox(width: 12.0),
                        Text(
                          '\$${widget.product.price.toStringAsFixed(2)}',
                          style: const TextStyle(
                            fontSize: 20.0,
                            color: AppColors.textLight,
                            decoration: TextDecoration.lineThrough,
                          ),
                        ),
                        const SizedBox(width: 8.0),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
                          decoration: BoxDecoration(
                            color: AppColors.secondary.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(6.0),
                          ),
                          child: Text(
                            '-${widget.product.discountPercentage.toStringAsFixed(0)}%',
                            style: TextStyle(
                              color: AppColors.secondary,
                              fontWeight: FontWeight.w600,
                              fontSize: 12.0,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 24.0),
                  const Text(
                    'Description',
                    style: TextStyle(
                      fontSize: 18.0,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 8.0),
                  Text(
                    widget.product.description,
                    style: TextStyle(
                      fontSize: 16.0,
                      color: AppColors.textSecondary,
                      height: 1.5,
                    ),
                  ),
                  if (widget.product.size != null) ...[
                    const SizedBox(height: 24.0),
                    const Text(
                      'Size',
                      style: TextStyle(
                        fontSize: 18.0,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 8.0),
                    Wrap(
                      spacing: 12.0,
                      children: ['S', 'M', 'L', 'XL'].map((size) {
                        return ChoiceChip(
                          label: Text(size),
                          selected: _selectedSize == size,
                          onSelected: (selected) {
                            setState(() => _selectedSize = selected ? size : null);
                          },
                        );
                      }).toList(),
                    ),
                  ],
                  if (widget.product.color != null) ...[
                    const SizedBox(height: 24.0),
                    const Text(
                      'Color',
                      style: TextStyle(
                        fontSize: 18.0,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 8.0),
                    Wrap(
                      spacing: 12.0,
                      children: ['Red', 'Blue', 'Black', 'White'].map((color) {
                        return ChoiceChip(
                          label: Text(color),
                          selected: _selectedColor == color,
                          onSelected: (selected) {
                            setState(() => _selectedColor = selected ? color : null);
                          },
                        );
                      }).toList(),
                    ),
                  ],
                  const SizedBox(height: 24.0),
                  Row(
                    children: [
                      const Text(
                        'Quantity',
                        style: TextStyle(
                          fontSize: 18.0,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const Spacer(),
                      Container(
                        decoration: BoxDecoration(
                          border: Border.all(color: AppColors.borderLight),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        child: Row(
                          children: [
                            IconButton(
                              icon: const Icon(Icons.remove),
                              onPressed: () {
                                if (_quantity > 1) {
                                  setState(() => _quantity--);
                                }
                              },
                            ),
                            SizedBox(
                              width: 40.0,
                              child: Center(
                                child: Text(
                                  _quantity.toString(),
                                  style: const TextStyle(
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.add),
                              onPressed: () {
                                setState(() => _quantity++);
                              },
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 32.0),
                  Row(
                    children: [
                      Expanded(
                        child: CustomButton(
                          text: 'Add to Cart',
                          variant: 'outlined',
                          onPressed: () {
                            cartProvider.addToCart(
                              widget.product,
                              quantity: _quantity,
                              size: _selectedSize,
                              color: _selectedColor,
                            );

                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Added to cart successfully'),
                                backgroundColor: AppColors.success,
                              ),
                            );
                          },
                        ),
                      ),
                      const SizedBox(width: 16.0),
                      Expanded(
                        child: CustomButton(
                          text: 'Buy Now',
                          onPressed: () {
                            cartProvider.addToCart(
                              widget.product,
                              quantity: _quantity,
                              size: _selectedSize,
                              color: _selectedColor,
                            );
                            // Navigate to checkout
                          },
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 40.0),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}