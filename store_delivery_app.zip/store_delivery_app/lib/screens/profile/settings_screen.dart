// lib/screens/profile/settings_screen.dart
import 'package:flutter/material.dart';
import '../../theme/app_colors.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _notificationsEnabled = true;
  bool _darkModeEnabled = false;
  bool _biometricEnabled = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildSectionHeader('NOTIFICATIONS'),
          _buildSwitchSetting(
            'Push Notifications',
            'Receive push notifications for orders and updates',
            _notificationsEnabled,
                (value) => setState(() => _notificationsEnabled = value),
          ),
          _buildSwitchSetting(
            'Email Notifications',
            'Receive email updates about your orders',
            true,
                (value) {},
          ),
          _buildSwitchSetting(
            'Promotional Notifications',
            'Receive notifications about special offers',
            true,
                (value) {},
          ),
          const SizedBox(height: 24),
          _buildSectionHeader('APPEARANCE'),
          _buildSwitchSetting(
            'Dark Mode',
            'Switch between light and dark theme',
            _darkModeEnabled,
                (value) => setState(() => _darkModeEnabled = value),
          ),
          const SizedBox(height: 24),
          _buildSectionHeader('SECURITY'),
          _buildSwitchSetting(
            'Biometric Login',
            'Use fingerprint or face ID to login',
            _biometricEnabled,
                (value) => setState(() => _biometricEnabled = value),
          ),
          _buildSettingItem(
            Icons.language_outlined,
            'Language',
            'English',
                () {
              // Show language selection
            },
          ),
          const SizedBox(height: 24),
          _buildSectionHeader('DATA'),
          _buildSettingItem(
            Icons.cloud_download_outlined,
            'Backup Data',
            'Last backup: 2 days ago',
                () {
              // Backup data
            },
          ),
          _buildSettingItem(
            Icons.delete_outline,
            'Clear Cache',
            '256 MB',
                () {
              _showClearCacheDialog(context);
            },
          ),
          const SizedBox(height: 32),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: ElevatedButton(
              onPressed: () {
                _showResetSettingsDialog(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.error.withOpacity(0.1),
                foregroundColor: AppColors.error,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text(
                'Reset All Settings',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: AppColors.textSecondary,
          letterSpacing: 1,
        ),
      ),
    );
  }

  Widget _buildSwitchSetting(
      String title,
      String subtitle,
      bool value,
      ValueChanged<bool> onChanged,
      ) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: SwitchListTile(
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w500)),
        subtitle: Text(subtitle, style: TextStyle(color: AppColors.textSecondary)),
        value: value,
        onChanged: onChanged,
      ),
    );
  }

  Widget _buildSettingItem(
      IconData icon,
      String title,
      String subtitle,
      VoidCallback onTap,
      ) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(icon, color: AppColors.primary),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w500)),
        subtitle: Text(subtitle, style: TextStyle(color: AppColors.textSecondary)),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }

  void _showClearCacheDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear Cache'),
        content: const Text('Are you sure you want to clear app cache?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Cache cleared successfully'),
                  backgroundColor: AppColors.success,
                ),
              );
            },
            child: const Text(
              'Clear',
              style: TextStyle(color: AppColors.error),
            ),
          ),
        ],
      ),
    );
  }

  void _showResetSettingsDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Reset Settings'),
        content: const Text('This will reset all settings to default. Are you sure?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                _notificationsEnabled = true;
                _darkModeEnabled = false;
                _biometricEnabled = false;
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Settings reset successfully'),
                  backgroundColor: AppColors.success,
                ),
              );
            },
            child: const Text(
              'Reset',
              style: TextStyle(color: AppColors.error),
            ),
          ),
        ],
      ),
    );
  }
}