// lib/theme/app_colors.dart
import 'package:flutter/material.dart';

class AppColors {
  // 🌿 PRIMARY COLORS (Dark Green Theme)
  static const Color primary = Color(0xFF1B5E20); // Dark Forest Green
  static const Color primaryLight = Color(0xFF4CAF50); // Medium Green
  static const Color primaryDark = Color(0xFF003300); // Deep Green

  // 🍃 SECONDARY COLORS
  static const Color secondary = Color(0xFF388E3C); // Leaf Green
  static const Color secondaryLight = Color(0xFF81C784); // Light Green
  static const Color secondaryDark = Color(0xFF2E7D32); // Darker Green

  // 🏔️ NEUTRAL COLORS
  static const Color background = Color(0xFFFFFFFF); // White
  static const Color surface = Color(0xFFF5F5F5); // Light Grey
  static const Color card = Color(0xFFF9F9F9);
  static const Color cardBackground = Color(0xFFF9F9F9);

  // 📝 TEXT COLORS
  static const Color textPrimary = Color(0xFF212121); // Dark Grey/Black
  static const Color textSecondary = Color(0xFF757575); // Muted Grey
  static const Color textLight = Color(0xFFBDBDBD); // Light Grey
  static const Color textWhite = Color(0xFFFFFFFF);

  // ✅ STATUS COLORS
  static const Color success = Color(0xFF4CAF50); // Green - Delivered
  static const Color warning = Color(0xFFFF9800); // Amber - Pending
  static const Color error = Color(0xFFF44336); // Red - Cancelled
  static const Color info = Color(0xFF2196F3); // Blue - Processing

  // 🔘 BUTTON COLORS
  static const Color buttonPrimary = Color(0xFF1B5E20); // Dark Green
  static const Color buttonSecondary = Color(0xFF757575);
  static const Color buttonSuccess = Color(0xFF4CAF50);
  static const Color buttonDanger = Color(0xFFF44336);

  // 🏷️ CATEGORY COLORS
  static const List<Color> categoryColors = [
    Color(0xFF1B5E20), // Electronics - Dark Green
    Color(0xFFD32F2F), // Fashion - Red
    Color(0xFF1976D2), // Home - Blue
    Color(0xFF7B1FA2), // Beauty - Purple
    Color(0xFFF57C00), // Sports - Orange
    Color(0xFF00796B), // Books - Teal
    Color(0xFFC2185B), // Toys - Pink
    Color(0xFF5D4037), // Grocery - Brown
  ];

  // 🎯 STATUS COLORS (Order Status)
  static const Color pending = Color(0xFFFF9800); // Amber
  static const Color processing = Color(0xFF2196F3); // Blue
  static const Color delivered = Color(0xFF4CAF50); // Green
  static const Color cancelled = Color(0xFFF44336); // Red

  // 📏 BORDER COLORS
  static const Color borderLight = Color(0xFFE0E0E0);
  static const Color borderDark = Color(0xFFBDBDBD);

  // 🌫️ SHADOW
  static const Color shadow = Color(0x1A000000);

  // ⭐ RATING
  static const Color rating = Color(0xFFFFC107);

  // 🌈 GRADIENT
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [Color(0xFF1B5E20), Color(0xFF4CAF50)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient secondaryGradient = LinearGradient(
    colors: [Color(0xFF388E3C), Color(0xFF81C784)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}