// lib/utils/constants.dart
import 'package:flutter/material.dart';

class AppConstants {
  static const String appName = 'Quick Cart';

  // API URLs (for future backend integration)
  static const String baseUrl = 'https://api.example.com';
  static const String apiVersion = '/v1';

  // Endpoints
  static const String loginEndpoint = '/auth/login';
  static const String registerEndpoint = '/auth/register';
  static const String productsEndpoint = '/products';
  static const String categoriesEndpoint = '/categories';
  static const String ordersEndpoint = '/orders';

  // Storage keys
  static const String tokenKey = 'auth_token';
  static const String userKey = 'user_data';
  static const String cartKey = 'cart_items';

  // Default values
  static const double defaultPadding = 16.0;
  static const double defaultRadius = 12.0;

  // Animation durations
  static const Duration defaultAnimationDuration = Duration(milliseconds: 300);
  static const Duration fastAnimationDuration = Duration(milliseconds: 150);

  // Mock data
  static const List<String> mockCategories = [
    'All', 'Electronics', 'Fashion', 'Home', 'Beauty', 'Sports', 'Books', 'Toys'
  ];

  static const List<Color> categoryColors = [
    Color(0xFF0066FF),
    Color(0xFFFF6B6B),
    Color(0xFF28A745),
    Color(0xFFFFC107),
    Color(0xFF6F42C1),
    Color(0xFF17A2B8),
    Color(0xFFDC3545),
    Color(0xFF6C757D),
  ];
}