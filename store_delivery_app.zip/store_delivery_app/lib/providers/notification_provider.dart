// lib/providers/notification_provider.dart
import 'package:flutter/material.dart';
import 'package:store_delivery_app/models/notification.dart' as notif;

class NotificationProvider with ChangeNotifier {
  List<notif.AppNotification> _notifications = [];
  bool _isLoading = false;

  List<notif.AppNotification> get notifications => _notifications;
  bool get isLoading => _isLoading;

  int get unreadCount => _notifications.where((n) => !n.isRead).length;

  Future<void> loadNotifications() async {
    _isLoading = true;
    notifyListeners();

    await Future.delayed(const Duration(seconds: 1));

    _notifications = [
      notif.AppNotification(
        id: '1',
        title: 'Order Confirmed',
        message: 'Your order #ORD001 has been confirmed.',
        type: notif.NotificationType.order,
        date: DateTime.now().subtract(const Duration(minutes: 10)),
      ),
      notif.AppNotification(
        id: '2',
        title: 'Special Offer',
        message: 'Get 20% off on all electronics.',
        type: notif.NotificationType.promotion,
        date: DateTime.now().subtract(const Duration(hours: 2)),
      ),
      notif.AppNotification(
        id: '3',
        title: 'Delivery Update',
        message: 'Your order will be delivered today.',
        type: notif.NotificationType.system,
        date: DateTime.now().subtract(const Duration(hours: 5)),
      ),
    ];

    _isLoading = false;
    notifyListeners();
  }

  void markAsRead(String id) {
    final index = _notifications.indexWhere((n) => n.id == id);
    if (index != -1) {
      _notifications[index] = _notifications[index].copyWith(isRead: true);
      notifyListeners();
    }
  }

  void markAllAsRead() {
    _notifications = _notifications.map((n) {
      return n.copyWith(isRead: true);
    }).toList();
    notifyListeners();
  }

  void addNotification(notif.AppNotification notification) {
    _notifications.insert(0, notification);
    notifyListeners();
  }

  void removeNotification(String id) {
    _notifications.removeWhere((n) => n.id == id);
    notifyListeners();
  }

  void clearAll() {
    _notifications.clear();
    notifyListeners();
  }
}