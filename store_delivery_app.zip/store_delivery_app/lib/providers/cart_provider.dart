// lib/providers/cart_provider.dart
import 'package:flutter/material.dart';
import 'package:store_delivery_app/models/cart_item.dart';
import 'package:store_delivery_app/models/product.dart';

class CartProvider with ChangeNotifier {
  final List<CartItem> _cartItems = [];

  // Simple ID counter instead of UUID
  int _idCounter = 1;

  List<CartItem> get cartItems => _cartItems;
  int get cartCount => _cartItems.fold(0, (sum, item) => sum + item.quantity);
  double get cartTotal => _cartItems.fold(0.0, (sum, item) => sum + item.totalPrice);

  void addToCart(Product product, {int quantity = 1, String? size, String? color}) {
    final existingItemIndex = _cartItems.indexWhere(
          (item) => item.product.id == product.id && item.size == size && item.color == color,
    );

    if (existingItemIndex != -1) {
      _cartItems[existingItemIndex].quantity += quantity;
    } else {
      _cartItems.add(CartItem(
        id: (_idCounter++).toString(), // Simple incrementing ID
        product: product,
        quantity: quantity,
        size: size,
        color: color,
      ));
    }
    notifyListeners();
  }

  void removeFromCart(String cartItemId) {
    _cartItems.removeWhere((item) => item.id == cartItemId);
    notifyListeners();
  }

  void updateQuantity(String cartItemId, int newQuantity) {
    if (newQuantity <= 0) {
      removeFromCart(cartItemId);
      return;
    }

    final itemIndex = _cartItems.indexWhere((item) => item.id == cartItemId);
    if (itemIndex != -1) {
      _cartItems[itemIndex].quantity = newQuantity;
      notifyListeners();
    }
  }

  void clearCart() {
    _cartItems.clear();
    notifyListeners();
  }

  bool isInCart(String productId) {
    return _cartItems.any((item) => item.product.id == productId);
  }
}