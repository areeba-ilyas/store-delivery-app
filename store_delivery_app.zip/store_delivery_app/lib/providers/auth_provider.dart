// lib/providers/auth_provider.dart
import 'package:flutter/material.dart';
import 'package:store_delivery_app/models/user.dart';

class AuthProvider with ChangeNotifier {
  User? _user;
  bool _isLoading = false;
  String? _error;

  User? get user => _user;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isAuthenticated => _user != null;

  Future<void> login(String email, String password) async {
    try {
      _isLoading = true;
      _error = null;
      notifyListeners();

      await Future.delayed(const Duration(seconds: 1));

      _user = User(
        id: '1',
        name: 'John Doe',
        email: email,
        phone: '+1234567890',
        address: '123 Main St, New York, NY 10001',
      );

      notifyListeners();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      rethrow;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> signup(String name, String email, String password, String phone) async {
    try {
      _isLoading = true;
      _error = null;
      notifyListeners();

      await Future.delayed(const Duration(seconds: 1));

      _user = User(
        id: '1',
        name: name,
        email: email,
        phone: phone,
        address: '123 Main St, New York, NY 10001',
      );

      notifyListeners();
    } catch (e) {
      _error = e.toString();
      notifyListeners();
      rethrow;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> logout() async {
    _user = null;
    notifyListeners();
  }

  void updateProfile(User updatedUser) {
    _user = updatedUser;
    notifyListeners();
  }
}