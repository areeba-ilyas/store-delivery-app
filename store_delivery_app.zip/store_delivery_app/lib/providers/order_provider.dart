// lib/providers/order_provider.dart
import 'package:flutter/material.dart';
import 'package:store_delivery_app/models/order.dart';
import 'package:store_delivery_app/utils/mock_data.dart';
import 'package:uuid/uuid.dart';

class OrderProvider with ChangeNotifier {
  final List<Order> _orders = [];
  bool _isLoading = false;
  String? _error;

  List<Order> get orders => _orders;
  bool get isLoading => _isLoading;
  String? get error => _error;

  OrderProvider() {
    _loadOrders();
  }

  Future<void> _loadOrders() async {
    _isLoading = true;
    notifyListeners();

    await Future.delayed(const Duration(seconds: 1));
    _orders.addAll(MockData.getOrders());

    _isLoading = false;
    notifyListeners();
  }

  Future<void> placeOrder(Order order) async {
    try {
      _isLoading = true;
      notifyListeners();

      await Future.delayed(const Duration(seconds: 1));
      _orders.insert(0, order);

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      rethrow;
    }
  }

  Order? getOrderById(String id) {
    try {
      return _orders.firstWhere((order) => order.id == id);
    } catch (e) {
      return null;
    }
  }

  List<Order> getOrdersByStatus(OrderStatus status) {
    return _orders.where((order) => order.status == status).toList();
  }

  void cancelOrder(String orderId) {
    final index = _orders.indexWhere((order) => order.id == orderId);
    if (index != -1) {
      // In real app, you would update status to cancelled
      notifyListeners();
    }
  }
}