import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:store_delivery_app/providers/auth_provider.dart';
import 'package:store_delivery_app/providers/cart_provider.dart';
import 'package:store_delivery_app/providers/order_provider.dart';
import 'package:store_delivery_app/providers/product_provider.dart';
import 'package:store_delivery_app/screens/auth/splash_screen.dart';
import 'package:store_delivery_app/theme/app_theme.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => ProductProvider()),
        ChangeNotifierProvider(create: (_) => CartProvider()),
        ChangeNotifierProvider(create: (_) => OrderProvider()),
      ],
      child: MaterialApp(
        title: 'Quick Cart',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme,
        home: const SplashScreen(),
      ),
    );
  }
}